<div class="slide-container">
        <span id="image1">
        </span>
        <span id="image2">
        </span>
        <span id="image3"></span>
        <div class="image-container">
          <img src="https://th.bing.com/th/id/OIP.YDFs1Tvk5g9nWh--Pj2WVQHaE7?w=252&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" class="slide-image">
          <img src="https://th.bing.com/th/id/OIP.3EP24T9hg8m6k1_CQYPDWgHaD4?w=324&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" class="slide-image">
          <img src="https://th.bing.com/th/id/OIP.Q7U_8nojG2w4MHgUBw_O-QHaEK?w=318&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" class="slide-image">
        </div>
        <div class="button-container">
          <a href="#image1" class="slider-button">
          </a>
          <a href="#image2" class="slider-button">
          </a>
          <a href="#image3" class="slider-button">
          </a>
        </div>
        
      </div>